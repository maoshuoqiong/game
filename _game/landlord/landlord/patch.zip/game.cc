#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <errno.h>

#include "landlord.h"
#include "log.h"
#include "game.h"
#include "proto.h"
#include "client.h"
#include "player.h"
#include "table.h"

extern Landlord landlord;
extern Log log;

void dump_game_info(char *tag)
{
#if 1
	static char buf[102400];
	int i = 0;
	i += sprintf(buf, "begin===============%s===============begin\n", tag);
    std::map<int, Table*>::iterator table_it;
    std::map<int, Client*>::iterator client_it;
    std::map<int, Player*>::iterator player_it;
    i += sprintf(buf + i, "[three_tables][%lu]\n", landlord.game->three_tables.size());
    for (table_it = landlord.game->three_tables.begin(); table_it != landlord.game->three_tables.end(); table_it++)
    {
        Table *table = table_it->second;
		i += sprintf(buf + i, "Tid[%d]state[%d] ", table_it->first, table->state);
        for (player_it = table->players.begin(); player_it != table->players.end(); player_it++)
        {
            Player *player = player_it->second;
            if (player->client)
                i += sprintf(buf + i, "uid[%d]fd[%d] ", player->uid, player->client->fd);
            else
                i += sprintf(buf + i, "uid[%d] ", player->uid);
        }
        i += sprintf(buf + i, "\n");
    }

    i += sprintf(buf + i, "[two_tables][%lu]\n", landlord.game->two_tables.size());
    for (table_it = landlord.game->two_tables.begin(); table_it != landlord.game->two_tables.end(); table_it++)
    {
        Table *table = table_it->second;
		i += sprintf(buf + i, "Tid[%d]state[%d] ", table_it->first, table->state);
        for (player_it = table->players.begin(); player_it != table->players.end(); player_it++)
        {
            Player *player = player_it->second;
            if (player->client)
                i += sprintf(buf + i, "uid[%d]fd[%d] ", player->uid, player->client->fd);
            else
                i += sprintf(buf + i, "uid[%d] ", player->uid);
        }
        i += sprintf(buf + i, "\n");
    }

    i += sprintf(buf + i, "[one_tables][%lu]\n", landlord.game->one_tables.size());
    for (table_it = landlord.game->one_tables.begin(); table_it != landlord.game->one_tables.end(); table_it++)
    {
        Table *table = table_it->second;
		i += sprintf(buf + i, "Tid[%d]state[%d] ", table_it->first, table->state);
        for (player_it = table->players.begin(); player_it != table->players.end(); player_it++)
        {
            Player *player = player_it->second;
            if (player->client)
                i += sprintf(buf + i, "uid[%d]fd[%d] ", player->uid, player->client->fd);
            else
                i += sprintf(buf + i, "uid[%d] ", player->uid);
        }
        i += sprintf(buf + i, "\n");
    }

    i += sprintf(buf + i, "[fd_client][%lu]\n", landlord.game->fd_client.size());
    for (client_it = landlord.game->fd_client.begin(); client_it != landlord.game->fd_client.end(); client_it++)
    {
        i += sprintf(buf + i, "fd[%d] ", client_it->first);
    }
	i += sprintf(buf + i, "\n");

    i += sprintf(buf + i, "[offline_players][%lu]\n", landlord.game->offline_players.size());
    for (player_it = landlord.game->offline_players.begin(); player_it != landlord.game->offline_players.end(); player_it++)
    {
        i += sprintf(buf + i, "uid[%d] ", player_it->first);
    }
	i += sprintf(buf + i, "\n");

    i += sprintf(buf + i, "[online_players][%lu]\n", landlord.game->online_players.size());
    for (player_it = landlord.game->online_players.begin(); player_it != landlord.game->online_players.end(); player_it++)
    {
        i += sprintf(buf + i, "uid[%d] ", player_it->first);
    }
	i += sprintf(buf + i, "\n");
    i += sprintf(buf + i, "end===============%s===============end\n", tag);
    log.debug("\n%s", buf);
#endif
}

Game::Game()
{
}

Game::~Game()
{
}

int Game::start()
{
    /* first init table */
    init_table();

    init_accept();

    return 0;
}

/* init table from config
 * todo read config from db or other */

int Game::init_table()
{
	int vid = landlord.conf["tables"]["vid"].asInt();
	int zid = landlord.conf["tables"]["zid"].asInt();
	int table_type = landlord.conf["tables"]["table_type"].asInt();
	int min_money = landlord.conf["tables"]["min_money"].asInt();
	int base_money = landlord.conf["tables"]["base_money"].asInt();
	log.debug("tables vid[%d] zid[%d] table_type[%d] min_money[%d] base_money[%d]\n", 
				vid, zid, table_type, min_money, base_money);
    for (int i = landlord.conf["tables"]["begin"].asInt(); i < landlord.conf["tables"]["end"].asInt(); i++)
    {
        Table *table = new Table();
        if (table->init(i, vid, zid, table_type, min_money, base_money) < 0)
        {
            log.error("table[%d] init err\n", i);
            exit(1);
        }
        zero_tables[i] = table;
		all_tables[i] = table;
	}
    log.debug("total tables[%d]\n", zero_tables.size());
	
	return 0;
}

int Game::init_accept()
{
    log.debug("Listening on %s:%d\n", 
            landlord.conf["game"]["host"].asString().c_str(),
            landlord.conf["game"]["port"].asInt());

    struct sockaddr_in addr;

    _fd = socket(PF_INET, SOCK_STREAM, 0);
    if (_fd < 0)
    {
    	log.error("File[%s] Line[%d]: socket failed: %s\n",
                    __FILE__, __LINE__, strerror(errno));
    }

    addr.sin_family      = AF_INET;
    addr.sin_port        = htons(landlord.conf["game"]["port"].asInt());
    addr.sin_addr.s_addr = inet_addr(landlord.conf["game"]["host"].asString().c_str());
	if (addr.sin_addr.s_addr == INADDR_NONE)
    {
		log.error("game::init_accept Incorrect ip address!");
        close(_fd);
		_fd = -1;
        exit(1);
    }

    int on = 1;
    if (setsockopt(_fd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on)) < 0)
    {
    	log.error("File[%s] Line[%d]: setsockopt failed: %s\n",
    					__FILE__, __LINE__, strerror(errno));
        close(_fd);
        return -1;
    }

    if (bind(_fd, (struct sockaddr *)&addr, sizeof(addr)) < 0)
    {
    	log.error("File[%s] Line[%d]: bind failed: %s\n",
    					__FILE__, __LINE__, strerror(errno));
        close(_fd);
        return -1;
    }

    fcntl(_fd, F_SETFL, fcntl(_fd, F_GETFL, 0) | O_NONBLOCK);
	
    listen(_fd, 10000);

    _ev_accept.data = this;
	ev_io_init(&_ev_accept, Game::accept_cb, _fd, EV_READ);
	ev_io_start(landlord.loop, &_ev_accept);

    log.debug("listen ok\n");

    return 0;
}

void Game::accept_cb(struct ev_loop *loop, struct ev_io *w, int revents)
{
	if (EV_ERROR & revents)
	{
        log.error("got invalid event\n");
		return;
	}
	
	struct sockaddr_in client_addr;
	socklen_t client_len = sizeof(client_addr);

	int fd = accept(w->fd, (struct sockaddr *)&client_addr, &client_len);
	if (fd < 0)
	{
        log.error("accept error[%s]\n", strerror(errno));
		return;
	}
	
	fcntl(fd, F_SETFL, fcntl(fd, F_GETFL, 0) | O_NONBLOCK);
	
	Client *client = new (std::nothrow) Client(fd);
    Game *game = (Game*)(w->data);
    if (client)
    {
        game->fd_client[fd] = client;
    }
    else close(fd);
}

void Game::del_client(Client *client)
{
    if (fd_client.find(client->fd) == fd_client.end())
    {
        log.error("free client err[miss]\n");
        return;
    }

	dump_msg("del_client begin");
	
    fd_client.erase(client->fd);
	
	// todo
	if (client->player)
	{
		Player *player = client->player;
		if (client->position == POSITION_WAIT) // todo delete this status
		{
			if (offline_players.find(player->uid) != offline_players.end())
		    {
		        offline_players.erase(player->uid);
		        log.debug("delete player[%d] offline\n", player->uid);
		    }
	
			if (online_players.find(player->uid) != online_players.end())
		    {
		        online_players.erase(player->uid);
		        log.debug("delete player[%d] online\n", player->uid);
		    }
			
			delete player;
		}
		else if (client->position == POSITION_TABLE)
		{
			if (online_players.find(player->uid) != online_players.end())
		    {
		        online_players.erase(player->uid);
				offline_players[player->uid] = client->player;
				// player->start_offline_timer();
				player->client = NULL;
		        log.debug("delete player[%d] online and add this uid to offline\n", player->uid);
		    }
			client->player->client = NULL;
		}
	}
	
	delete client;
	dump_game_info("del client end");
	dump_msg("del_client end");
}

int Game::dispatch(Client *client)
{
	client->cmd_type = 0;
    int cmd = client->packet.test();
    log.debug("comd %d\n", cmd);
	if (cmd < 0)
	{
		log.error("the cmd format is error.\n");
		return -1;
	}

    if (cmd == SYS_ECHO)
    {
        Jpacket packet;
        packet.val = client->packet.val;
        packet.end();
        return client->send(packet.tostring());
    }

    if (cmd == SYS_ONLINE)
    {
    	client->cmd_type = 1;
        Jpacket packet;
        packet.val["cmd"] = SYS_ONLINE;
        packet.val["online"] = (int)(online_players.size() + offline_players.size());
        packet.end();
        return client->send(packet.tostring());
    }
	
	if (cmd == CLIENT_HEART_BEAT)
	{
		return 0;
	}
	
	if (cmd == CLIENT_JOIN_TABLE_REQ)
	{
		if (client->player == NULL)
		{
			int ret = add_player(client);
			if (ret == -1)
			{
				return -1;
			} else if (ret == 1) {
				return 0;
			} else if (ret == 2) {
				return 0;
			}
			return handler_join_table(client);
		}
		log.error("CLIENT_JOIN_TABLE_REQ player must be NULL.\n");
		return -1;
	}
		
	if (safe_check(client, cmd) < 0)
	{
		return -1;
	}
	
    Player *player = client->player;
	
    /* dispatch */
    switch (cmd)
    {
    case CLIENT_GAME_READY_REQ:
        all_tables[player->tid]->handler_game_ready(player);
        break;
	case CLIENT_PREPLAY_ONE_REQ:
		all_tables[player->tid]->handler_preplay(player);
		break;
	case CLIENT_PREPLAY_TWO_REQ:
		all_tables[player->tid]->handler_preplay(player);
		break;
	case CLIENT_PLAY_CARD_REQ:
		all_tables[player->tid]->handler_play_card(player);
		break;
	case CLIENT_CHAT_REQ:
		all_tables[player->tid]->handler_chat(player);
		break;
	case CLIENT_FACE_REQ:
		all_tables[player->tid]->handler_face(player);
		break;
	case CLIENT_LOGOUT_REQ:
		del_player(player);
		break;
	case CLIENT_ROBOT_REQ:
		all_tables[player->tid]->handler_robot(player);
		break;
    default:
        log.error("invalid command[%d]\n", cmd);
        return -1;
    }
	
    // log.debug("dispatch succ\n");
    return 0;
}

int Game::safe_check(Client *client, int cmd)
{
	if (online_players.find(client->uid) == online_players.end())
	{
		log.error("player[%d] must be online player.\n", client->uid);
		return -1;
	}
	
	Player *player = client->player;
	if (all_tables.find(player->tid) == all_tables.end())
	{
		log.error("safe_check uid[%d] is not in table[%d]\n", player->uid, player->tid);
		return -1;
	}
	
	return 0;
}

int Game::handler_join_table(Client *client)
{
	dump_game_info("handler_join_table begin");
	dump_msg("handler_join_table begin");
	Player *player = client->player;

    if (client->position == POSITION_TABLE)
    {
    	log.debug("handler_join_table uid[%d] have been in table\n", player->uid);
        return -1;
    }

	if (two_tables.size() > 0)
	{
		log.debug("two_tables.size() > 0\n");
			
		map<int, Table*>::iterator two_it;
		for (two_it = two_tables.begin(); two_it != two_tables.end(); two_it++)
		{
			// two_it = two_tables.begin();
			Table *table = (*two_it).second;
			if (table->state == END_GAME)
			{
				continue;
			}
			if (table->players.find(player->uid) != table->players.end())
			{
				log.debug("handler_join_table uid[%d] is in table[%d]\n", player->uid, table->tid);
				return -1;
			}
			two_tables.erase(two_it);
			three_tables[table->tid] = table;
			
			client->set_positon(POSITION_TABLE);
			table->add_player(client->player);
			
			table->table_info_broadcast();
			
			dump_msg("handler_join_table end");
			dump_game_info("handler_join_table end");
			return 0;
		}
	}
	
	if (one_tables.size() > 0)
	{
		log.debug("one_tables.size() > 0 && wait_queue.size() > 0\n");

		map<int, Table*>::iterator one_it;
		for (one_it = one_tables.begin(); one_it != one_tables.end(); one_it++)
		{
			Table *table = (*one_it).second;
			if (table->state == END_GAME)
			{
				continue;
			}
			if (table->players.find(player->uid) != table->players.end())
			{
				log.debug("handler_join_table uid[%d] is in table[%d]\n", player->uid, table->tid);
				return -1;
			}
			one_tables.erase(one_it);
			two_tables[table->tid] = table;
			
			client->set_positon(POSITION_TABLE);
			table->add_player(client->player);
			
			table->table_info_broadcast();
			
			dump_msg("handler_join_table end");
			dump_game_info("handler_join_table end");
			return 0;
		}
	}
	
	if (zero_tables.size() > 0)
	{
		log.debug("zero_tables.size() > 0 && wait_queue.size() > 1\n");
			
		map<int, Table*>::iterator zero_it;
		for (zero_it = zero_tables.begin(); zero_it != zero_tables.end(); zero_it++)
		{
			Table *table = (*zero_it).second;
			if (table->state == END_GAME)
			{
				continue;
			}
			if (table->players.find(player->uid) != table->players.end())
			{
				log.debug("handler_join_table uid[%d] is in table[%d]\n", player->uid, table->tid);
				return -1;
			}
			zero_tables.erase(zero_it);
			one_tables[table->tid] = table;
			
			client->set_positon(POSITION_TABLE);
			table->add_player(client->player);
			
			table->table_info_broadcast();

			dump_msg("handler_join_table end");
			dump_game_info("handler_join_table end");
			return 0;
		}
	}
	

	log.error("no seat\n");
	return -1;
}

int Game::update_table(int tid)
{
	dump_game_info("update table 0");
	map<int, Table*>::iterator it;
	it = all_tables.find(tid);
	if (it == all_tables.end())
	{
		return -1;
	}
	Table *table = (*it).second;
	
	it = three_tables.find(tid);
	if (it != three_tables.end())
	{
		three_tables.erase(it);
		two_tables[tid] = table;
		dump_msg("update table 1");
		dump_game_info("update table 1");
		return 0;
	}
	
	it = two_tables.find(tid);
	if (it != two_tables.end())
	{
		two_tables.erase(it);
		one_tables[tid] = table;
		dump_msg("update table 2");
		dump_game_info("update table 2");
		return 0;
	}
	
	it = one_tables.find(tid);
	if (it != one_tables.end())
	{
		one_tables.erase(it);
		zero_tables[tid] = table;
		dump_msg("update table 3");
		dump_game_info("update table 3");
		return 0;
	}
	
	return -1;
}

int Game::send_error(Client *client, int cmd, int error_code)
{
    Jpacket error;
    error.val["cmd"] = cmd;
    error.val["err"] = error_code;
    error.end();
    return client->send(error.tostring());
}

void Game::dump_msg(string msg)
{
	log.debug("%s zero[%d] one[%d] two[%d] three[%d] fd_client[%d] offline[%d] online[%d]\n",
			msg.c_str(), zero_tables.size(), one_tables.size(), two_tables.size(), three_tables.size(),
			fd_client.size(), offline_players.size(), online_players.size());	
}

int Game::check_skey(Client *client)
{
	if (client->uid < 10000)
	{
		return 0;
	}
	
	int i = client->uid % landlord.main_size;
	int ret = landlord.main_rc[i]->command(" hget u:%d skey", client->uid);
	if (ret < 0)
	{
		log.debug("player init error, because get player infomation error.\n");
		return -1;
	}
#if 1
	log.debug("skey [%s] [%s]\n", client->skey.c_str(), landlord.main_rc[i]->reply->str);
	if (landlord.main_rc[i]->reply->str && client->skey.compare(landlord.main_rc[i]->reply->str) != 0)
	{
		log.error("skey [%s] [%s]\n", client->skey.c_str(), landlord.main_rc[i]->reply->str);
		return -1;
	}
#endif	
	return 0;
}

int Game::add_player(Client *client)
{
    Json::Value &val = client->packet.tojson();
    int uid = val["uid"].asInt();
	client->uid = uid;
	client->skey = val["skey"].asString();
	client->vid = val["vid"].asInt();
	client->zid = val["zid"].asInt();
	
	if (check_skey(client) < 0)
	{
		return -1;
	}
	
	/* rebind by online */
    if (online_players.find(uid) != online_players.end())
    {
#if 1
        log.debug("player[%d] rebind by online get info ok\n", uid);
		Player *player = online_players[uid];
		if (all_tables.find(player->tid) == all_tables.end())
		{
			log.error("rebind by online uid[%d] is not in table[%d]\n", player->uid, player->tid);
			return -1;
		}
		Client *oldClient = player->client;
        player->set_client(client);
		client->set_positon(POSITION_TABLE);
		all_tables[player->tid]->handler_rebind(player);
	    fd_client.erase(oldClient->fd);
		delete oldClient;
		dump_game_info("rebind by online");
		
        return 2;
#endif
        // return -1;
    }
	
    /* rebind by offline */
    if (offline_players.find(uid) != offline_players.end())
    {
        log.debug("player[%d] rebind by offline get info ok\n", uid);
		
		Player *player = offline_players[uid];
		if (all_tables.find(player->tid) == all_tables.end())
		{
			log.error("rebind by offline uid[%d] is not in table[%d]\n", player->uid, player->tid);
			return -1;
		}
        offline_players.erase(uid);
        online_players[uid] = player;
		
        player->set_client(client);
		client->set_positon(POSITION_TABLE);
		all_tables[player->tid]->handler_rebind(player);
		dump_game_info("rebind by offline");
        return 1;
    }

    /* set player info */
    Player *player = new (std::nothrow) Player();
    if (player == NULL)
    {
        log.error("new player err");
        return -1;
    }
	
    player->set_client(client);
	int ret = player->init();
	if (ret < 0)
		return -1;
    online_players[uid] = player;
	dump_game_info("add player end");
    log.debug("player[%d] login success on game.cc\n", uid);

    return 0;
}

int Game::del_player(Player *player)
{
    log.debug("player_p[%p]\n", player);
	
    int ret;
	
	ret = all_tables[player->tid]->handler_logout(player);
	if (ret < 0)
	{
		log.debug("del_player handler_logout\n");
		return -1;	
	}
	
	ret = all_tables[player->tid]->del_player(player);
	if (ret < 0)
	{
		log.debug("del_player del_player\n");
		return -1;	
	}
	
	ret = update_table(player->tid);
	if (ret < 0)
	{
		log.debug("del_player update_table\n");
		return -1;	
	}
	
	if (offline_players.find(player->uid) != offline_players.end())
    {
        offline_players.erase(player->uid);
        log.debug("delete player[%d] offline\n", player->uid);
    }
	
	if (online_players.find(player->uid) != online_players.end())
    {
        online_players.erase(player->uid);
        log.debug("delete player[%d] online\n", player->uid);
    }
	
	if (player->client)
	{
		Client *client = player->client;
		client->position = POSITION_WAIT;
		Client::pre_destroy(client);
		client->player = NULL;
		delete player;
		return 0;
	}
	
    log.debug("delete player[%p] uid[%d]\n", player, player->uid);
    delete player;
	dump_msg("del_player end");
	dump_game_info("del_player");
    return 0;
}
